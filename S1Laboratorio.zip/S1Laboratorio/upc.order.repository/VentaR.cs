﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using upc.order.entities;

namespace upc.order.repository
{
    public class VentaR : IVentaR
    {
        SqlConnection Sqlcon;
        //Static ==> Patron Singleton
        Conexion cn = new Conexion();
        public bool Create(Venta v)
        {
            Sqlcon = cn.getConexion();
            //SQL
            SqlCommand cmd = new SqlCommand("sp_addventa", Sqlcon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", v.Producto);
            cmd.Parameters.AddWithValue("@cantidad", v.Cantidad);

            Sqlcon.Open();
            int i = cmd.ExecuteNonQuery();
            Sqlcon.Close();

            if (i >= -1)
                return true;
            else
                return false;
        }
    }
}
